package com.knalog.kominalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KominalogApplication {

	public static void main(String[] args) {
		SpringApplication.run(KominalogApplication.class, args);
	}

}
