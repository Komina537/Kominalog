package com.knalog.kominalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KominalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
